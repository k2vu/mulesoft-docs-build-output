/*
 * $Id: IdentificationService.java 18780 2011-03-10 20:11:09Z travis.carlson $
 * --------------------------------------------------------------------------------------
 *
 * (c) 2003-2010 MuleSoft, Inc. This software is protected under international copyright
 * law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 * (or other master license agreement) separately entered into in writing between you and
 * MuleSoft. If such an agreement is not in place, you may not use the software.
 */
package com.mulesoft.mule.example.widget;

import models.Widget;
import org.mule.api.MuleContext;
import org.mule.api.context.MuleContextAware;


public class IdentificationService implements MuleContextAware {

    private MuleContext muleContext;
    
    public void setMuleContext(MuleContext muleContext)
    {
        this.muleContext = muleContext;
    }

    public Widget identify(Widget widget)
    {
        String id = muleContext.getConfiguration().getId() + " @ " + muleContext.getConfiguration().getMuleHomeDirectory();
        widget.setManufacturer(id);
        widget.addVisitedNode(muleContext.getClusterNodeId());
        return widget;
    }    
}
