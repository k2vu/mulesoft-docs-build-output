/*
 * $Id$
 * --------------------------------------------------------------------------------------
 *
 * (c) 2003-2010 MuleSoft, Inc. This software is protected under international copyright
 * law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 * (or other master license agreement) separately entered into in writing between you and
 * MuleSoft. If such an agreement is not in place, you may not use the software.
 */
package com.mulesoft.mule.example.widget;

import models.Widget;
import org.mule.api.MuleEventContext;
import org.mule.api.lifecycle.Callable;


public class NewWidgetService implements Callable
{
    public Object onCall(MuleEventContext eventContext) throws Exception
    {
        Widget widget = new Widget();
        widget.setLabel(eventContext.transformMessageToString().trim());
        widget.addVisitedNode(eventContext.getMuleContext().getClusterNodeId());
        return widget;
    }    
}
