/*
 * $Id: URIBuilder.java 23505 2011-12-20 08:20:49Z mike.schilling $
 * --------------------------------------------------------------------------------------
 * Copyright (c) MuleSoft, Inc.  All rights reserved.  http://www.mulesoft.com
 *
 * The software in this package is published under the terms of the CPAL v1.0
 * license, a copy of which has been included with this distribution in the
 * LICENSE.txt file.
 */
package com.mulesoft.mule.example.widget;

import org.mule.api.MuleContext;
import org.mule.api.MuleException;
import org.mule.api.client.LocalMuleClient;
import org.mule.api.context.MuleContextAware;
import org.mule.api.lifecycle.Startable;
import org.mule.api.lifecycle.Stoppable;
import org.mule.client.DefaultLocalMuleClient;

import java.util.Timer;
import java.util.TimerTask;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class EventGenerator implements MuleContextAware, Startable, Stoppable
{
    private static Log logger = LogFactory.getLog(EventGenerator.class);

    private String payload;
    private long delay;
    private long interval;
    private MuleContext muleContext;
    private LocalMuleClient muleClient;
    private Timer timer;
    private String targetUrl;

    public void setTargetUrl(String targetUrl)
    {
        this.targetUrl = targetUrl;
    }

    public void setPayload(String payload)
    {
        this.payload = payload;
    }

    public void setDelay(long delay)
    {
        this.delay = delay;
    }

    public void setInterval(long interval)
    {
        this.interval = interval;
    }

    @Override
    public void setMuleContext(MuleContext muleContext)
    {
        this.muleContext = muleContext;
        this.muleClient = new DefaultLocalMuleClient(muleContext);
    }

    @Override
    public void start() throws MuleException
    {
        timer = new Timer("widgetEventTimer", true);
        timer.schedule(new Task(), delay, interval);
    }

    @Override
    public void stop() throws MuleException
    {
        if (timer != null)
        {
            timer.cancel();            
        }
    }
    
    class Task extends TimerTask
    {

        @Override
        public void run()
        {
            try
            {
                muleClient.send(targetUrl, payload, null);
            } 
            catch (MuleException e)
            {
                logger.warn("Error dispatching event", e);
            }
        }
    }
}
