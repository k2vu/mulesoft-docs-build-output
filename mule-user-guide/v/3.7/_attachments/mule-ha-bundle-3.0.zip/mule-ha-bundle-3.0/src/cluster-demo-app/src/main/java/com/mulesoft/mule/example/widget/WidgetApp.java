/*
 * $Id: WidgetApp.java 19420 2011-09-14 22:13:24Z victor.bonillo $
 * --------------------------------------------------------------------------------------
 *
 * (c) 2003-2010 MuleSoft, Inc. This software is protected under international copyright
 * law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 * (or other master license agreement) separately entered into in writing between you and
 * MuleSoft. If such an agreement is not in place, you may not use the software.
 */
package com.mulesoft.mule.example.widget;

import java.io.IOException;

import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Session;

import models.Widget;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.broker.BrokerService;

/**
 * Runs the Widget example application.
 */
public class WidgetApp
{
    public static final String JMS_URI = "tcp://0.0.0.0:61616";
    public static final String INBOUND_QUEUE = "incoming.widgets";
    public static final String OUTBOUND_QUEUE = "completed.widgets";
    /** Each component will take this long (in ms) to process the event. */
    public static final int PROCESSING_DELAY = 1000;

    // JMS
    protected BrokerService broker;
    protected Connection jmsConnection = null;
    protected Session jmsOutboundSession;
    protected MessageConsumer jmsOutboundConsumer;
    private Object lock;

    public static void main(String[] args) throws Exception
    {
        WidgetApp app = new WidgetApp();
        app.run();
    }

    public WidgetApp() throws Exception
    {
        Runtime.getRuntime().addShutdownHook(new Thread() 
        {
            public void run() 
            {
                try
                {
                    stopJms();
                }
                catch (Exception e)
                {
                    System.err.println(e.getMessage());
                }
            }
        });
    }

    protected void startJms() throws Exception
    {
        System.out.println("Starting JMS Provider...");
        broker = new BrokerService();
        // JMX makes ActiveMQ hang at shutdown when tests are run off-line
        broker.setUseJmx(false);
        broker.addConnector(JMS_URI);
        broker.start();
        Thread.sleep(2000);

        jmsConnection = new ActiveMQConnectionFactory(JMS_URI).createConnection();
        jmsConnection.setClientID(getClass().getName());
        jmsConnection.start();
    }

    protected void stopJms() throws Exception
    {
        stopJmsOutboundConsumer();
        if (jmsConnection != null)
        {
            jmsConnection.close();
            jmsConnection = null;
        }

        if (broker != null)
        {
            System.out.println("Stopping JMS Provider...");
            try
            {
                broker.deleteAllMessages();
                broker.stop();
                Thread.sleep(2000);
            }
            finally
            {
                broker = null;
            }
        }
    }

    protected void run() throws Exception
    {
        startJms();
        startJmsOutboundConsumer();
        
        int response = 0;
        while (response != 'q')
        {
            System.out.println("\n1. Manufacture 1 widget\n2. Manufacture 10 widgets\n3. Manufacture 100 widgets\nq. Quit");

            response = readCharacter();

            switch (response)
            {
                case '1' :
                {
                    sendRequests(1);
                    break;
                }

                case '2' :
                {
                    sendRequests(10);
                    break;
                }

                case '3' :
                {
                    sendRequests(100);
                    break;
                }

                case 'q' :
                {
                    System.out.println("Goodbye");
                    stopJms();
                    System.exit(0);
                }

                default :
                {
                    System.out.println("Option not recognized");
                }
            }
            // Give Mule a chance to process the last request before we spit out the
            // menu again
            Thread.sleep(2000);
        }
    }

    public void sendRequests(int numMessages) throws Exception
    {
        sendJmsMessages(new Widget(), numMessages);
        System.out.println(numMessages + " requests sent");
    }

    protected void sendJmsMessages(Object payload, int numMessages) throws Exception
    {
        Session session = null;
        try
        {
            session = jmsConnection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            Destination destination = session.createQueue(INBOUND_QUEUE);
            MessageProducer producer = null;
            try
            {
                producer = session.createProducer(destination);
                for (int i = 0; i < numMessages; i++)
                {
                    ((Widget) payload).setLabel(new Integer(i+1).toString());
                    ObjectMessage msg = session.createObjectMessage();
                    msg.setObject((Widget) payload);
                    producer.send(msg);
                }
            }
            finally
            {
                if (producer != null)
                {
                    producer.close();
                }
            }
        }
        finally
        {
            if (session != null)
            {
                session.close();
            }
        }
    }

    protected void startJmsOutboundConsumer() throws Exception
    {
        jmsOutboundSession = jmsConnection.createSession(false, Session.AUTO_ACKNOWLEDGE);
        Destination destination = jmsOutboundSession.createQueue(OUTBOUND_QUEUE);
        jmsOutboundConsumer = jmsOutboundSession.createConsumer(destination);
        jmsOutboundConsumer.setMessageListener(new MessageListener()
        {
            public void onMessage(javax.jms.Message message)
            {
                if (!(message instanceof ObjectMessage))
                {
                    throw new IllegalArgumentException("ObjectMessage expected but "
                                                       + message.getClass().getName() + " received");
                }
                try
                {
                    System.out.println(((ObjectMessage) message).getObject());
                }
                catch (JMSException e)
                {
                    throw new RuntimeException(e);
                }
            }
        });
    }

    protected void stopJmsOutboundConsumer() throws Exception
    {
        if (jmsOutboundConsumer != null)
        {
            jmsOutboundConsumer.close();
            jmsOutboundConsumer = null;
        }
        if (jmsOutboundSession != null)
        {
            jmsOutboundSession.close();
            jmsOutboundSession = null;
        }
    }

    protected static int readCharacter() throws IOException
    {
        byte[] buf = new byte[16];
        System.in.read(buf);
        return buf[0];
    }
}
