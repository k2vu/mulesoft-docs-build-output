/*
 * $Id: ColorService.java 18092 2010-10-27 17:15:44Z travis.carlson $
 * --------------------------------------------------------------------------------------
 *
 * (c) 2003-2010 MuleSoft, Inc. This software is protected under international copyright
 * law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 * (or other master license agreement) separately entered into in writing between you and
 * MuleSoft. If such an agreement is not in place, you may not use the software.
 */
package com.mulesoft.mule.example.widget;


import models.Widget;
import org.mule.api.MuleContext;
import org.mule.api.context.MuleContextAware;

public class ColorService implements MuleContextAware
{
    private static final String[] COLORS = {"red", "yellow", "blue"};

    private MuleContext muleContext;

    public Widget color(Widget widget)
    {
        widget.setColor(COLORS[getRandom()]);
        widget.addVisitedNode(muleContext.getClusterNodeId());
        return widget;
    }

    public void setMuleContext(MuleContext muleContext)
    {
        this.muleContext = muleContext;
    }

    protected static int getRandom()
    {
        return new Double(Math.random() * 3).intValue();
    }
}
